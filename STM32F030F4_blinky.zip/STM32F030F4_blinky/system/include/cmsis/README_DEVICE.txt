The stm32f0xx.h and system_stm32f0xx.h files are from 
STM32F0xx_StdPeriph_Lib_V1.5.0.zip, the folder:

	STM32F0xx_StdPeriph_Lib_V1.5.0/Libraries/CMSIS/Device/ST/STM32F0xx/Include

The cmsis_device.h is added for convenience.

